#!/usr/bin/env python3
"""
将 TinyStories 文本数据转换为 np.memmap 格式的 Token 序列
"""
import numpy as np
import json
import sys
import re
from tqdm import tqdm

# GPT-2 BPE 分词器实现
class BPETokenizer:
    def __init__(self, vocab_path, merges_path):
        # 加载词表
        with open(vocab_path, 'r', encoding='utf-8') as f:
            self.vocab = json.load(f)
        self.id_to_token = {v: k for k, v in self.vocab.items()}

        # 加载合并规则
        with open(merges_path, 'r', encoding='utf-8') as f:
            content = f.read()
        merges = content.split('\n')[1:]  # 跳过头部
        merges = [tuple(m.split()) for m in merges if m and len(m.split()) == 2]
        self.bpe_ranks = {merge: i for i, merge in enumerate(merges)}

        # 构建字节编码映射
        self.byte_encoder = self._bytes_to_unicode()
        self.byte_decoder = {v: k for k, v in self.byte_encoder.items()}

        # 正则表达式用于分词
        self.pat = re.compile(r"""'s|'t|'re|'ve|'m|'ll|'d| ?\w+| ?\d+| ?[^\s\w\d]+|\s+(?!\S)|\s+""")

    def _bytes_to_unicode(self):
        bs = list(range(ord("!"), ord("~")+1)) + list(range(ord("¡"), ord("¬")+1)) + list(range(ord("®"), ord("ÿ")+1))
        cs = bs[:]
        n = 0
        for b in range(2**8):
            if b not in bs:
                bs.append(b)
                cs.append(2**8+n)
                n += 1
        cs = [chr(n) for n in cs]
        return dict(zip(bs, cs))

    def _get_pairs(self, word):
        pairs = set()
        prev_char = word[0]
        for char in word[1:]:
            pairs.add((prev_char, char))
            prev_char = char
        return pairs

    def _bpe(self, token):
        word = tuple(token)
        pairs = self._get_pairs(word)

        if not pairs:
            return token

        while True:
            bigram = min(pairs, key=lambda pair: self.bpe_ranks.get(pair, float('inf')))
            if bigram not in self.bpe_ranks:
                break

            first, second = bigram
            new_word = []
            i = 0
            while i < len(word):
                try:
                    j = word.index(first, i)
                    new_word.extend(word[i:j])
                    i = j
                except:
                    new_word.extend(word[i:])
                    break

                if word[i] == first and i < len(word)-1 and word[i+1] == second:
                    new_word.append(first+second)
                    i += 2
                else:
                    new_word.append(word[i])
                    i += 1

            word = tuple(new_word)
            if len(word) == 1:
                break
            else:
                pairs = self._get_pairs(word)

        return ' '.join(word)

    def encode(self, text):
        bpe_tokens = []
        for token in re.findall(self.pat, text):
            token = ''.join(self.byte_encoder[b] for b in token.encode('utf-8'))
            bpe_tokens.extend(self.vocab[bpe_token] for bpe_token in self._bpe(token).split(' '))
        return bpe_tokens

    def decode(self, tokens):
        text = ''.join([self.id_to_token[token] for token in tokens])
        text = bytearray([self.byte_decoder[c] for c in text]).decode('utf-8', errors='replace')
        return text


def encode_and_save(text_file, output_file, tokenizer):
    """编码文本并保存为 .bin 文件"""
    print(f"处理文件: {text_file}")

    all_ids = []
    with open(text_file, 'r', encoding='utf-8') as f:
        for line in tqdm(f, desc="编码中"):
            line = line.strip()
            if line:
                ids = tokenizer.encode(line)
                all_ids.extend(ids)
            
            # 每 1000 万 tokens 打印一次进度
            if len(all_ids) > 0 and len(all_ids) % 10000000 == 0:
                print(f"已处理 {len(all_ids):,} 个 tokens")

    arr = np.array(all_ids, dtype=np.uint16)
    arr.tofile(output_file)

    print(f"保存到: {output_file}")
    print(f"总 Token 数: {len(arr):,}")
    print(f"文件大小: {len(arr) * 2 / 1024 / 1024:.2f} MB")
    return arr


if __name__ == '__main__':
    # 初始化分词器
    print("加载 BPE 分词器...")
    tokenizer = BPETokenizer(
        '/root/llm-from-scratch/trained_tokenizer/vocab.json',
        '/root/llm-from-scratch/trained_tokenizer/merges.txt'
    )
    print(f"词表大小: {len(tokenizer.vocab)}")

    # 编码训练集
    print("\n开始处理训练集...")
    encode_and_save(
        '/root/llm-from-scratch/train_data/train.txt',
        '/root/llm-from-scratch/tokenized_data/train.bin',
        tokenizer
    )

    # 编码验证集
    print("\n开始处理验证集...")
    encode_and_save(
        '/root/llm-from-scratch/train_data/val.txt',
        '/root/llm-from-scratch/tokenized_data/val.bin',
        tokenizer
    )

    print("\n数据处理完成！")
